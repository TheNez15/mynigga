# Terraformer-GCP

A CLI tool that generates .tf and tfstate files based on existing infrastructure (reverse Terraform).

* Status: beta - we still need to improve documentation, squash some bugs, etc...
* Created by: Waze SRE
* Updated/Maintained for tZero by: James Celli


## Getting Started
After cloning the repo run the following:

* `cd terraformer-gcp`
* `./scripts/runit.sh [GCP_PROJECT_NAME] [GCP_PROJECT_REGION]`

When the script completes you will have a directory in the `projects` directory named with the  `[GCP_PROJECT]` variable. Inside of the `[GCP_PROJECT]` folder will be another folder structure of all of the exported resources as `.tf` and `.tstate` files.

## Capabilities
* Generate tf + tfstate files from existing infrastructure for all supported objects by resource.
* Remote state can be uploaded to a GCS bucket.
* Connect between resources with terraform_remote_state (local and bucket).
* Save tf files using a custom folder tree pattern.
* Import by resource name and type.

Terraformer uses terraform providers and is designed to easily support newly added resources. To upgrade resources with new fields, all you need to do is upgrade the relevant terraform providers.

```
Import current State to terraform configuration from google cloud

Usage:
   import google [flags]
   import google [command]

Available Commands:
  list        List supported resources for google provider

Flags:
  -b, --bucket string         gs://terraform-state
  -c, --connect                (default true)
  -f, --filter strings        google_compute_firewall=id1:id2:id4
  -h, --help                  help for google
  -o, --path-output string     (default "generated")
  -p, --path-pattern string   {output}/{provider}/custom/{service}/ (default "{output}/{provider}/{service}/")
      --projects strings
  -z, --regions strings       europe-west1, (default [global])
  -r, --resources strings     firewalls,networks
  -s, --state string          local or bucket (default "local")

Use " import google [command] --help" for more information about a command.
```

## Permissions
Read-only permissions

## Filtering
Filters are a way to choose which resources terraformer imports.

For example:

```
terraformer import aws --resources=vpc,subnet --filter=aws_vpc=myvpcid --regions=eu-west-1
```
will import only one VPC and all subnets from all VPCs (not just the ones from the filtered VPC)

#### Resources ID
Filtering is based on Terraform resource ID patterns. To find valid ID patterns for your resource, check the import part of [Terraform documentation][9c6d1756].

  [9c6d1756]: https://www.terraform.io/docs/providers/ "Terraform Providers Documentation."

#### Planning
The ```plan``` command generates a planfile that contains all the resources set to be imported. By modifying the planfile before running the ```import``` command, you can rename or filter the resources you'd like to import.

The rest of subcommands and parameters are identical to the ```import``` command.

```
$ terraformer plan google --resources=networks,firewalls --projects=my-project --zone=europe-west1-d
(snip)

Saving planfile to generated/google/my-project/terraformer/plan.json
```
After reviewing/customizing the planfile, begin the import by running import plan.

```
$ terraformer import plan generated/google/my-project/terraformer/plan.json
```

### Installation
From source:

Run ```git clone <terraformer repo>```
Run ```GO111MODULE=on go mod vendor```
Run ```go build -v```
Run ```terraform init``` against an init.tf file to install the plugins required for your platform. For example, if you need plugins for the google provider, init.tf should contain:
```
provider "google" {}
```
Or alternatively

Copy your Terraform provider's plugin(s) to folder ```~/.terraform.d/plugins/{darwin,linux}_amd64/```, as appropriate.

###### From Releases:

##### Linux
```
curl -LO https://github.com/GoogleCloudPlatform/terraformer/releases/download/$(curl -s https://api.github.com/repos/GoogleCloudPlatform/terraformer/releases/latest | grep tag_name | cut -d '"' -f 4)/terraformer-linux-amd64
chmod +x terraformer-linux-amd64
sudo mv terraformer-linux-amd64 /usr/local/bin/terraformer
```
##### MacOS
```
curl -LO https://github.com/GoogleCloudPlatform/terraformer/releases/download/$(curl -s https://api.github.com/repos/GoogleCloudPlatform/terraformer/releases/latest | grep tag_name | cut -d '"' -f 4)/terraformer-darwin-amd64
chmod +x terraformer-darwin-amd64
sudo mv terraformer-darwin-amd64 /usr/local/bin/terraformer
```
##### Using a package manager
If you want to use a package manager:

Homebrew users can use ```brew install terraformer```.

Links to download terraform providers:

* google cloud provider >2.0.0 - [here](https://releases.hashicorp.com/terraform-provider-google/)
* aws provider >1.56.0 - [here](https://releases.hashicorp.com/terraform-provider-aws/)
* openstack provider >1.17.0 - [here](https://releases.hashicorp.com/terraform-provider-openstack/)
* kubernetes provider >=1.4.0 - [here](https://releases.hashicorp.com/terraform-provider-kubernetes/)
* github provider >=2.0.0 - [here](https://releases.hashicorp.com/terraform-provider-github/)
* datadog provider >1.19.0 - [here](https://releases.hashicorp.com/terraform-provider-datadog/)

Information on provider plugins: https://www.terraform.io/docs/configuration/providers.html


#### Use with GCP

Example:

```
terraformer import google --resources=gcs,forwardingRules,httpHealthChecks --connect=true --regions=europe-west1,europe-west4 --projects=aaa,fff
terraformer import google --resources=gcs,forwardingRules,httpHealthChecks --filter=google_compute_firewall=rule1:rule2:rule3 --regions=europe-west1 --projects=aaa,fff
```
##### List of supported GCP services:

* ```addresses```
  - ```google_compute_address```
* ```autoscalers```
  - ```google_compute_autoscaler```
* ```backendBuckets```
  - ```google_compute_backend_bucket```
* ```backendServices```
  - ```google_compute_backend_service```
* ```bigQuery```
  - ```google_bigquery_dataset```
  - ```google_bigquery_table```
* ```schedulerJobs```
  - ```google_cloud_scheduler_job```
* ```disks```
  - ```google_compute_disk```
* ```firewalls```
  - ```google_compute_firewall```
* ```forwardingRules```
  - ```google_compute_forwarding_rule```
* ```globalAddresses```
  - ```google_compute_global_address```
* ```globalForwardingRules```
  - ```google_compute_global_forwarding_rule```
* ```healthChecks```
  - ```google_compute_health_check```
* ```httpHealthChecks```
  - ```google_compute_http_health_check```
* ```httpsHealthChecks```
  - ```google_compute_https_health_check```
* ```images```
  - ```google_compute_image```
* ```instanceGroupManagers```
  - ```google_compute_instance_group_manager```
* ```instanceGroups```
  - ```google_compute_instance_group```
* ```instanceTemplates```
  - ```google_compute_instance_template```
* ```instances```
  - ```google_compute_instance```
* ```interconnectAttachments```
  - ```google_compute_interconnect_attachment```
* ```memoryStore```
  - ```google_redis_instance```
* ```networks```
  - ```google_compute_network```
* ```nodeGroups```
  - ```google_compute_node_group```
* ```nodeTemplates```
  - ```google_compute_node_template```
* ```regionAutoscalers```
  - ```google_compute_region_autoscaler```
* ```regionBackendServices```
  - ```google_compute_region_backend_service```
* ```regionDisks```
  - ```google_compute_region_disk```
* ```regionInstanceGroupManagers```
  - ```google_compute_region_instance_group_manager```
* ```routers```
  - ```google_compute_router```
* ```routes```
  - ```google_compute_route```
* ```securityPolicies```
  - ```google_compute_security_policy```
* ```sslPolicies```
  - ```google_compute_ssl_policy```
* ```subnetworks```
  - ```google_compute_subnetwork```
* ```targetHttpProxies```
  - ```google_compute_target_http_proxy```
* ```targetHttpsProxies```
  - ```google_compute_target_https_proxy```
* ```targetInstances```
  - ```google_compute_target_instance```
* ```targetPools```
  - ```google_compute_target_pool```
* ```targetSslProxies```
  - ```google_compute_target_ssl_proxy```
* ```targetTcpProxies```
  - ```google_compute_target_tcp_proxy```
* ```targetVpnGateways```
  - ```google_compute_vpn_gateway```
* ```urlMaps```
  - ```google_compute_url_map```
* ```vpnTunnels```
  - ```google_compute_vpn_tunnel```
* ```gke```
  - ```google_container_cluster```
  - ```google_container_node_pool```
* ```pubsub```
  - ```google_pubsub_subscription```
  - ```google_pubsub_topic```
* ```dataProc```
  - ```google_dataproc_cluster```
* ```cloudFunctions```
  - ```google_cloudfunctions_function```
* ```gcs```
  - ```google_storage_bucket```
  - ```google_storage_bucket_acl```
  - ```google_storage_default_object_acl```
  - ```google_storage_bucket_iam_binding```
  - ```google_storage_bucket_iam_member```
  - ```google_storage_bucket_iam_policy```
  - ```google_storage_notification```
* ```monitoring```
  - ```google_monitoring_alert_policy```
  - ```google_monitoring_group```
  - ```google_monitoring_notification_channel```
  - ```google_monitoring_uptime_check_config```
* ```dns```
  - ```google_dns_managed_zone```
  - ```google_dns_record_set```
* ```cloudsql```
  - ```google_sql_database_instance```
  - ```google_sql_database```
* ```kms```
  - ```google_kms_key_ring```
  - ```google_kms_crypto_key```
* ```project```
  - ```google_project```

Your tf and tfstate files are written by default to ```generated/gcp/zone/service```.
