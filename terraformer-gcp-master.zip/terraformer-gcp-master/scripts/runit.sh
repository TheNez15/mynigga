#! /bin/bash

#============================================================================
####                      FUNCTIONS                                      ####
#============================================================================

function progress () {
  secs=$1
  shift
  msg=$*
  while [ $secs -gt 0 ]
  do
    printf "\r\033[KWaiting %.d seconds $msg" $((secs--))
    sleep 1
  done
  echo
}


#============================================================================
####                      SCRIPTING TEMPLATES                            ####
#============================================================================

# #### This is a template for printing a message to the terminal.
# echo ""
# echo ""
# echo ""
# echo "        ...."
# sleep 2
# echo ""
# echo ""

# #### This is a switch statement that is used for asking the user if they would like to proceed.
# while true; do
#   read -r -p "" CONTINUE
#   case ${CONTINUE} in
#     [yY] | [yY][Ee][Ss] )
#       echo ""
#       echo ""
#       echo ""
#       ;;
#     [nN] | [n|N][O|o] )
#       echo ""
#       echo ""
#       echo ""
#       ;;
#     * )
#       echo "Please enter Y/y or N/n."
#       ;;
#   esac
# done

#============================================================================
####                      VARIABLES                                      ####
#============================================================================

# Current working directory.
CURRENT=$(pwd)
export CURRENT

# The GCP Project Name that was supplied.
GCP_PROJECT=${1}
export GCP_PROJECT

# The GCP Project Region that was supplied.
GCP_REGION=${2}
export GCP_REGION

declare ALL_WORKING_PARSED_SERVICES=([1]addresses [2]autoscalers [3]backendBuckets [4]backendServices [5]bigQuery [6]disks [7]firewalls [8]forwardingRules [9]globalAddresses [10]globalForwardingRules [11]healthChecks [12]httpHealthChecks [13]httpsHealthChecks [14]images [15]instanceGroupManagers [16]instanceGroups [17]instanceTemplates [18]instances [19]interconnectAttachments [20]networks [21]nodeGroups [22]nodeTemplates [23]regionAutoscalers [24]regionBackendServices [25]regionDisks [26]regionInstanceGroupManagers [27]routers [28]routes [29]securityPolicies [30]sslPolicies [31]subnetworks [32]targetHttpProxies [33]targetHttpsProxies [34]targetInstances [35]targetPools [36]targetSslProxies [37]targetTcpProxies [38]targetVpnGateways [39]urlMaps [40]vpnTunnels [41]gke [42]pubsub [43]gcs [44]dns [45]cloudsql [46]kms [47]project)

#============================================================================

clear
cat << EOF

                      ██╗  ██╗██╗   ██╗██████╗ ███████╗██████╗  ██████╗███████╗██╗     ██╗     ██╗      ██╗███╗   ██╗███████╗████████╗ █████╗ ██╗     ██╗     ███████╗
                      ██║ ██╔╝██║   ██║██╔══██╗██╔════╝██╔══██╗██╔════╝██╔════╝██║     ██║     ██║      ██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██║     ██║     ██╔════╝
                      █████╔╝ ██║   ██║██████╔╝█████╗  ██████╔╝██║     █████╗  ██║     ██║     ██║█████╗██║██╔██╗ ██║███████╗   ██║   ███████║██║     ██║     ███████╗
                      ██╔═██╗ ██║   ██║██╔══██╗██╔══╝  ██╔══██╗██║     ██╔══╝  ██║     ██║     ██║╚════╝██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║     ██║     ╚════██║
                      ██║  ██╗╚██████╔╝██████╔╝███████╗██║  ██║╚██████╗███████╗███████╗███████╗██║      ██║██║ ╚████║███████║   ██║   ██║  ██║███████╗███████╗███████║
                      ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚══════╝╚══════╝╚══════╝╚═╝      ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝

                                                                        Starting the Terraformer-GCP Process.
EOF
sleep 1
clear
sleep 1


# Checks to see if the user entered parameters with the command for the ENV Variables.
if [ $# -eq '0' ]
then
  echo ""
  echo ""
  echo "No arguments supplied. Please re-run the command as follows: "
  echo ""
  echo "Example Command: ./startup.sh \${GCP_PROJECT} \${GCP_REGION}"
  echo ""
  echo "---------------------------------------------"
  echo "You need to pass the following variables into the script in this order:"
  echo "GCP_PROJECT  <-- This is the GCP Project that you would like to export as terraform files."
  echo "---------------------------------------------"
  echo ""
  echo ""
  exit
else
  clear
  echo ""
  echo ""
  echo "         SETTING UP THE CURRENT WORKING ENVIRONMENT    "
  echo ""
  echo ""
  sleep 1
  echo "                   SETTING UP VARIABLES      "
  echo ""
  echo ""
  echo "           GCP Project Name:     -------->     ${GCP_PROJECT}"
  echo "           Region:               -------->     ${GCP_REGION}"
  # echo "           Cluster Name:         -------->     ${}"
  echo ""
  echo ""
  sleep 2
  clear
fi


## Step 2: Check to see if there is a folder for the project that was supplied to the command.
while true; do
read -r -p "Would you like to create the folder structure needed to export the .tf files for ${GCP_PROJECT}[Y/n]: " CONTINUE
case ${CONTINUE} in
  [yY] | [yY][Ee][Ss] )
    ## Step 1: Check to see if a folder for GCP Projects exists.
    if [ -d "projects" ]; then
      echo ""
      echo "You already have a Projects directory."
      echo ""
      sleep .5
      echo ""
      echo "Skipping to the next step."
    else
      mkdir $CURRENT/projects
      echo ""
      echo "Created the 'Project' directory."
      echo ""
    fi
    ## Step 3: Check the specific folder for the GCP Project supplied to see if there is an init.tf file.
    if [ -d "${CURRENT}/projects/${GCP_PROJECT}" ]; then
      echo ""
      echo "You already have a directory for the ${GCP_PROJECT} GCP Project."
      sleep .5
      echo ""
      echo ""
      echo "Skipping to the next step."
      echo ""
    else
      mkdir ${CURRENT}/projects/${GCP_PROJECT}
      echo ""
      echo ""
      echo "Created the directory for the ${GCP_PROJECT} GCP Project."
      echo ""
      echo ""
    fi
    break
    ;;
  [nN] | [n|N][O|o] )
    echo ""
    echo ""
    echo "Have a nice day! :)"
    echo ""
    echo ""
    sleep 1
    clear
    exit
    ;;
  * )
    echo "Please enter Y/y or N/n."
    ;;
esac
done

## Account Type to export the terraform from: GCP, AWS
## Coming Soon: OpenStack, k8s, GitHub, DataDog
while true; do
  read -r -p "Which Cloud Hosting provider would you like to export from?[GCP, AWS]: " CLOUD_PROVIDER
  case ${CLOUD_PROVIDER} in
    GCP|gcp )
      echo ""
      echo ""
      echo "You stated that your Cloud Hosting Provider is GCP"
      echo ""
      echo ""
      if [[ -f "projects/${GCP_PROJECT}/init.tf" ]]; then
        echo "You already have the needed file in the directory. (init.tf)"
      else
        echo "Moving over the init.tf file."
        cp templates/init-GCP.tf projects/${GCP_PROJECT}/init.tf
      fi
      break
      ;;
    AWS|aws )
      echo ""
      echo ""
      echo "You stated that your Cloud Hosting Provider is AWS"
      echo ""
      if [[ -f "projects/${AWS_PROJECT}/init.tf" ]]; then
        echo "You already have the needed file in the directory. (init.tf)"
      else
        echo "Moving over the init.tf file."
        cp templates/init-GCP.tf projects/${AWS_PROJECT}/init.tf
      fi
      break
      ;;
    * )
      echo "Please enter GCP or AWS."
      ;;
  esac
done

## Need to check for what APIs have been enabled on the account, prior to exporting the files.
echo ""
echo ""
echo "Creating the enabled-services file in the ${GCP_PROJECT} folder."
touch ${CURRENT}/projects/${GCP_PROJECT}/enabled-services
gcloud services list | awk 'FNR == 1 {next} {print $1}' | sed 's/.googleapis.com//g' > ${CURRENT}/projects/${GCP_PROJECT}/enabled-services
ENABLED_SERVICES=(`gcloud services list | awk 'FNR == 1 {next} {print $1}' | tr '\n' ','  | sed 's/.googleapis.com//g' | sed 's/,$//'`)

## Have the user verify that the GCP project configured in the shell is the one they would like to export.
CUR_PROJECT=`gcloud config list | grep project | awk '{print $3}'`
while true; do
  read -r -p "Your shell session is currently set for ${CUR_PROJECT}; are you sure you want to export that GCP Project?[Y/n]: " CONTINUE
  case ${CONTINUE} in
    [yY] | [yY][Ee][Ss] )
      ## Ask if the user would like to export all of the resources as .tf files.
      echo ""
      echo ""
      echo "Starting the export process."
      echo ""
      if [[ $CURRENT != "${CURRENT}/projects/${GCP_PROJECT}" ]]; then
        cd ${CURRENT}/projects/${GCP_PROJECT}
      fi
      echo ""
      echo ""
      echo "Initializing Terraform."
      terraform init
      echo ""
      echo ""

      ENABLED_FILE="${CURRENT}/projects/${GCP_PROJECT}/enabled-services"

      for i in "${ALL_WORKING_PARSED_SERVICES[*]}"; do
        echo $i | tr -s '[*]' ' ' | \
        tr -s '[:digit:]' ' ' | \
        tr -s ' ' ','
      done > ${CURRENT}/projects/${GCP_PROJECT}/services

      PARSED_SERVICES=$(cat ${CURRENT}/projects/${GCP_PROJECT}/services | sed 's/,addresses,/addresses,/' | sed 's/cloudsql/cloudsql/')

      sed -e 's/\<cloudapis\>//g; s/\<cloudsql\>//g; s/\<cloudbilling\>//g; s/\<cloudbuild\>//g; s/\<clouddebugger\>//g; s/\<cloudresourcemanager\>//g; s/\<cloudtrace\>//g; s/\<containeranalysis\>//g; s/\<datastore\>//g; s/\<deploymentmanager\>//g; s/\<endpoints\>//g; s/\<iam\>//g; s/\<iamcredentials\>//g; s/\<logging\>//g; s/\<monitoring\>//g; s/\<oslogin\>//g; s/\<runtimeconfig\>//g; s/\<servicecontrol\>//g; s/\<servicemanagement\>//g; s/\<serviceusage\>//g; s/\<sqladmin\>//g; s/\<storage-component\>//g' ${CURRENT}/projects/${GCP_PROJECT}/services
      clear
      echo ""
      echo "STARTING THE EXPORT PROCESS....."
      echo ""
      echo ""
      sleep 2


      ## Exporting the resources as .tf files.
      terraformer import google \
        --resources=${PARSED_SERVICES[*]} \
        --connect=true \
        --path-output="./generated-tf-files" \
        --path-pattern="{output}/{service}" \
        --regions=${GCP_REGION} \
        --projects=${GCP_PROJECT}
        echo ""
        echo ""
        echo "PROCESS COMPLETE! Have a nice day! :)"
        echo ""
        echo ""
      break
      ;;
    [nN] | [n|N][O|o] )
      echo ""
      echo ""
      echo "Nothing has been done. Have a nice day! :)"
      exit
      ;;
    * )
      echo "Please enter Y/y or N/n."
      ;;
  esac
done
